package com.movielisting;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MovieServlet")
public class MovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MovieDao movieDao;

    public void init() {
        movieDao = new MovieDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "new":
                showNewForm(request, response);
                break;
            case "insert":
                try {
                    addMovie(request, response);
                } catch (IOException | SQLException e) {
                    e.printStackTrace();
                }
                break;
            case "delete":
                try {
                    deleteMovie(request, response);
                } catch (IOException | SQLException e) {
                    e.printStackTrace();
                }
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "update":
                try {
                    updateMovie(request, response);
                } catch (IOException | SQLException e) {
                    e.printStackTrace();
                }
                break;
            case "list-user":
            	listMoviesForAnotherJSP(request, response);
                
            case "list":
            	listMovies(request, response);
                break;
            default:
            	 listMovies(request, response);
                break;
        }
    }

    private void listMovies(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Movie> listMovies = movieDao.selectAllMovies();
        request.setAttribute("listMovies", listMovies);
        request.getRequestDispatcher("movie-list.jsp").forward(request, response);
    }

    private void listMoviesForAnotherJSP(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Movie> listMovies = movieDao.selectAllMovies();
        request.setAttribute("listMovies", listMovies);
        request.getRequestDispatcher("Movie-Listing.jsp").forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("movie-form.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Movie existingMovie = movieDao.selectMovie(id);
        request.setAttribute("movie", existingMovie);
        request.getRequestDispatcher("movie-form.jsp").forward(request, response);
    }

    private void addMovie(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
        String title = request.getParameter("title");
        String type = request.getParameter("type");
        String language = request.getParameter("language");
        String director = request.getParameter("director");
        String description = request.getParameter("description");
        String image = request.getParameter("image");
        Movie newMovie = new Movie(0, title, type, language, director, description, image);
        movieDao.insertMovie(newMovie);
        response.sendRedirect("MovieServlet?action=list");
    }

    private void updateMovie(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        String title = request.getParameter("title");
        String type = request.getParameter("type");
        String language = request.getParameter("language");
        String director = request.getParameter("director");
        String description = request.getParameter("description");
        String image = request.getParameter("image");
        Movie movie = new Movie(id, title, type, language, director, description, image);
        movieDao.updateMovie(movie);
        response.sendRedirect("MovieServlet?action=list");
    }

    private void deleteMovie(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        movieDao.deleteMovie(id);
        response.sendRedirect("MovieServlet?action=list");
    }
}
