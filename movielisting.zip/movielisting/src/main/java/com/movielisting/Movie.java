package com.movielisting;

public class Movie {
    private int id;
    private String title;
    private String type;
    private String language;
    private String director;
    private String description;
    private String image;

    public Movie() {
    }

    public Movie(int id, String title, String type, String language, String director, String description, String image) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.language = language;
        this.director = director;
        this.description = description;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Movie [id=" + id + ", title=" + title + ", type=" + type + ", language=" + language + ", director="
                + director + ", description=" + description + ", image=" + image + "]";
    }
}
