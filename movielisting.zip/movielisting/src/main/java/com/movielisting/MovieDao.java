package com.movielisting;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.movielisting.Movie;

public class MovieDao {

    private String jdbcURL = "jdbc:mysql://localhost:3306/movielisting?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_MOVIE_SQL = "INSERT INTO movies (title, type, language, director, description, image) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_MOVIE_BY_ID = "SELECT * FROM movies WHERE id=?";
    private static final String SELECT_ALL_MOVIES = "SELECT * FROM movies";
    private static final String DELETE_MOVIE_SQL = "DELETE FROM movies WHERE id=?";
    private static final String UPDATE_MOVIE_SQL = "UPDATE movies SET title=?, type=?, language=?, director=?, description=?, image=? WHERE id=?";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertMovie(Movie movie) throws SQLException {
        try (Connection connection = getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(INSERT_MOVIE_SQL)) {
            preparedStatement.setString(1, movie.getTitle());
            preparedStatement.setString(2, movie.getType());
            preparedStatement.setString(3, movie.getLanguage());
            preparedStatement.setString(4, movie.getDirector());
            preparedStatement.setString(5, movie.getDescription());
            preparedStatement.setString(6, movie.getImage());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean updateMovie(Movie movie) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(UPDATE_MOVIE_SQL)) {
            statement.setString(1, movie.getTitle());
            statement.setString(2, movie.getType());
            statement.setString(3, movie.getLanguage());
            statement.setString(4, movie.getDirector());
            statement.setString(5, movie.getDescription());
            statement.setString(6, movie.getImage());
            statement.setInt(7, movie.getId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public Movie selectMovie(int id) {
        Movie movie = null;
        try (Connection connection = getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MOVIE_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String title = rs.getString("title");
                String type = rs.getString("type");
                String language = rs.getString("language");
                String director = rs.getString("director");
                String description = rs.getString("description");
                String image = rs.getString("image");
                movie = new Movie(id, title, type, language, director, description, image);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movie;
    }

    public List<Movie> selectAllMovies() {
        List<Movie> movies = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_MOVIES);
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String type = rs.getString("type");
                String language = rs.getString("language");
                String director = rs.getString("director");
                String description = rs.getString("description");
                String image = rs.getString("image");
                movies.add(new Movie(id, title, type, language, director, description, image));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return movies;
    }

    public boolean deleteMovie(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(DELETE_MOVIE_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }
}
